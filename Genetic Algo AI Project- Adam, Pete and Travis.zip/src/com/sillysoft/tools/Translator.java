package com.sillysoft.tools;

import java.util.Locale;

public class Translator
{

/** Get the value for the given key in a currently loaded locale and the default bundle. */
public static String getString(String key)
	{
	return null;
	}
		
/** Return the currently loaded Locale. */
public static Locale getLocale()
	{
	return null;
	}

/** Get the value for the given key in a currently loaded locale and the default bundle. */
public static String getEditorString(String key)
	{
	return null;
	}


}
